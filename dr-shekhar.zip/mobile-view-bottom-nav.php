<div class="mobile-view-bottom-nav">
        <div class="conatiner">
            <div class="mobile-view-bottom-nav-container">
                <a href="#">
                    <span><i class="fa-solid fa-house"></i></span>
                    <span>Home</span>
                </a>
                <a href="#">
                    <span><i class="fa-brands fa-whatsapp"></i></span>
                    <span>Chat</span>
                </a>
                <a href="#">
                    <span><i class="fa-solid fa-address-card"></i></span>
                    <span>About</span>
                </a>
                <a href="#">
                   <span><i class="fa-brands fa-blogger-b"></i></span>
                    <span>Blogs</span>
                </a>
                <a href="#">
                    <span><i class="fa-solid fa-question"></i></span>
                    <span>FAQs</span>
                </a>
            </div>
        </div>
      </div>